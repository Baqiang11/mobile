/* Include files */

#include "lab3_cgxe.h"
#include "m_YzSvjDBmrSRNodPVfPoCK.h"

unsigned int cgxe_lab3_method_dispatcher(SimStruct* S, int_T method, void* data)
{
  if (ssGetChecksum0(S) == 3323308392 &&
      ssGetChecksum1(S) == 2565578906 &&
      ssGetChecksum2(S) == 479663628 &&
      ssGetChecksum3(S) == 2558073976) {
    method_dispatcher_YzSvjDBmrSRNodPVfPoCK(S, method, data);
    return 1;
  }

  return 0;
}
